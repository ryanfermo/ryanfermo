package com.ryanfermo.dl_form;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    Button btn2;
    private Button btn;
    EditText Ln,Fn,Mn,condition,type,weight,height,nationality,province,street,city,bod,code,res,eye,sex;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ln = findViewById(R.id.editTextTextPersonName);
        Fn = findViewById(R.id.editTextTextPersonName2);
        Mn = findViewById(R.id.editTextTextPersonName3);
        condition = findViewById(R.id.editTextTextPersonName14);
        type = findViewById(R.id.editTextTextPersonName13);
        weight = findViewById(R.id.editTextTextPersonName7);
        height = findViewById(R.id.editTextTextPersonName10);
        nationality = findViewById(R.id.editTextTextPersonName9);
        province = findViewById(R.id.editTextTextPersonName6);
        street = findViewById(R.id.editTextTextPersonName4);
        city = findViewById(R.id.editTextTextPersonName5);
        bod = findViewById(R.id.editTextTextPersonName8);
        code = findViewById(R.id.editTextTextPersonName11);
        res = findViewById(R.id.editTextTextPersonName12);
        eye = findViewById(R.id.editTextTextPersonName15);
        sex = findViewById(R.id.editTextTextPersonName16);
        btn = findViewById(R.id.button);
        btn2 = findViewById(R.id.button2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(MainActivity.this);
                builder.setTitle("Confirmation");
                builder.setMessage("Do you want to proceed with the Driver License?");
                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String Lan, Fin, Min, condition1, type1, weight1, height1, nationality1, province1, street1, city1, bod1, code1, res1, eye1, sex1;
                        Intent intent = new Intent(MainActivity.this, Driver_License.class);
                        Lan = Ln.getText().toString();
                        Fin = Fn.getText().toString();
                        Min = Mn.getText().toString();
                        condition1 = condition.getText().toString();
                        type1 = type.getText().toString();
                        weight1 = weight.getText().toString();
                        height1 = height.getText().toString();
                        nationality1 = nationality.getText().toString();
                        province1 = province.getText().toString();
                        street1 = street.getText().toString();
                        city1 = city.getText().toString();
                        bod1 = bod.getText().toString();
                        code1 = code.getText().toString();
                        res1 = res.getText().toString();
                        eye1 = eye.getText().toString();
                        sex1 = sex.getText().toString();
                        intent.putExtra("sex", sex1);
                        intent.putExtra("Ln", Lan);
                        intent.putExtra("Fn", Fin);
                        intent.putExtra("Mn", Min);
                        intent.putExtra("condition", condition1);
                        intent.putExtra("type", type1);
                        intent.putExtra("weight", weight1);
                        intent.putExtra("height", height1);
                        intent.putExtra("nationality", nationality1);
                        intent.putExtra("province", province1);
                        intent.putExtra("street", street1);
                        intent.putExtra("city", city1);
                        intent.putExtra("bod", bod1);
                        intent.putExtra("code", code1);
                        intent.putExtra("res", res1);
                        intent.putExtra("eye", eye1);
                        startActivity(intent);
                    }
                }).setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                });
                builder.show();
            }
        });}

    public void btnFunction2(View view) {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}
