package com.ryanfermo.dl_form;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class Driver_License extends AppCompatActivity {
    TextView textView21,textView28,textView26,textView25,textView24,textView23,textView38,textView37,textView34,textView33,textView32,textView30;
    ImageView img;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver__license);
        textView21=findViewById(R.id.textView21);
        textView28=findViewById(R.id.textView28);
        textView26=findViewById(R.id.textView26);
        textView25=findViewById(R.id.textView25);
        textView24=findViewById(R.id.textView24);
        textView23=findViewById(R.id.textView23);
        textView38=findViewById(R.id.textView38);
        textView37=findViewById(R.id.textView37);
        textView34=findViewById(R.id.textView34);
        textView33=findViewById(R.id.textView33);
        textView32=findViewById(R.id.textView32);
        textView30=findViewById(R.id.textView30);
        Intent intent=getIntent();
        String Lan=intent.getStringExtra("Ln");
        String Fin=intent.getStringExtra("Fn");
        String Min=intent.getStringExtra("Mn");
        String condition1=intent.getStringExtra("condition");
        String type1=intent.getStringExtra("type");
        String weight1=intent.getStringExtra("weight");
        String height1=intent.getStringExtra("height");
        String nationality1=intent.getStringExtra("nationality");
        String province1=intent.getStringExtra("province");
        String street1=intent.getStringExtra("street");
        String city1=intent.getStringExtra("city");
        String bod1=intent.getStringExtra("bod");
        String code1=intent.getStringExtra("code");
        String res1=intent.getStringExtra("res");
        String eye1=intent.getStringExtra("eye");
        String sex1=intent.getStringExtra("sex");
        int date=1000;
        date=date+1;
        textView21.setText(Lan+","+Fin +","+Min);
        textView23.setText("  "+nationality1);
        textView24.setText(sex1);
        textView25.setText(weight1);
        textView26.setText(height1);
        textView28.setText(bod1);
        textView30.setText(street1+","+city1 +","+province1);
        textView32.setText(code1+"-"+"10"+"-"+date);
        textView33.setText("2050/10/04");
        textView34.setText(code1);
        textView37.setText("  "+type1+"                 "+eye1);
        textView38.setText("  "+res1+"                  "+condition1);
        img=findViewById(R.id.imageView4);
        if(textView24.getText().toString().equals("M")){
            img.setImageResource(R.drawable.boy);
        }
        else if(textView24.getText().toString().equals("F")){
            img.setImageResource(R.drawable.girl);
        }
        else{
        }
    btn=findViewById(R.id.button4);
    btn.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
            View view = findViewById(R.id.main_layout_id);
            String message = "Please Click Confirm to print your Driver License";
            int duration = Snackbar.LENGTH_INDEFINITE;
            showSnackbar(view, message, duration);
        }
    });
}
    public void showSnackbar(View view, String message, int duration)
    {
        final Snackbar snackbar = Snackbar.make(view, message, duration);
        snackbar.setAction("Confirm", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Printer is NOT YET Available!", Toast.LENGTH_LONG).show();
                snackbar.dismiss();
                snackbar.setActionTextColor(getResources().getColor(R.color.purple_700));
            }
        });
        snackbar.show();
}
    public void btnedit(View view) {
        finish();
        System.exit(0);
    }

    public void btnexit(View view) {
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}